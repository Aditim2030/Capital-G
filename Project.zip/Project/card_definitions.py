class Card:
    def __init__(self,card_name,colour_card,card_cost,monument_cost,owner,rent_prices,monument_built):
        self.card_name=card_name
        self.monument_cost=monument_cost
        self.colour_card=colour_card
        self.card_cost=card_cost
        self.owner=owner
        self.rent_prices=rent_prices
    def sell(self,player):
        "ownership"
        player.add_balance(self.card_cost)
        self.owner='Bank'
    def purchase_card(self,player):
        if self.card_cost>player.balance:
            print("You cannot afford this card at the moment.")
        else:
            player.cards_owned.append(self)
            player.reduce_balance(self.card_cost)
            self.owner=player
    def construct_monument(self,player):
        if self.monument_cost > player.balance:
            print("You cannot afford a monument at the moment on this property")
        else:
            self.monument_built+=1
        print(f"You have built a house on {self.cardname}.")
    def locate_card_object(name,board):
        for card in board:
            if card.card_name==name:
                card_object=card
                break
        return card_object



    

    


    
    
    

    