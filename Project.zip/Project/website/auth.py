from flask import Blueprint

auth=Blueprint('auth',__name__)

@auth.route('/game')
def game():
    return "<p>Start Playing</p>"
@auth.route('/end_game')
def end_game():
    return "<p> The game ended </p>"
@auth.route('/details')
def details():
    return "<p>details</p>"

